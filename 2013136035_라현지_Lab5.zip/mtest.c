#include <stdio.h>
int main()
{
   InFoo();
   InBoo();
   InBar();
   return 0;
}
