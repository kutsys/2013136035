#include <stdio.h>

void InFoo()
{
  printf("InFoo function call!! \n");
}
